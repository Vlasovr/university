# Лабораторная работа №6  
## Многопоточная сортировка индексного файла с отображением в память

valgrind --leak-check=full --show-leak-kinds=all -s ./build view  index.dat
valgrind --leak-check=full --show-leak-kinds=all -s ./build/gen 4096 index.dat
valgrind --leak-check=full --show-leak-kinds=all -s ./build/sort_index 65536 8 4 m index.dat

### 📄 Описание

Программа `sort_index` выполняет сортировку вторичного индексного файла с использованием многопоточности. Она поддерживает два режима:
- Использование `read()`/`write()`
- Использование отображения файла в память с помощью `mmap()`

Также включены утилиты:
- `gen` — генерация тестового файла с неотсортированными записями
- `view` — просмотр содержимого файла

### 🗂 Структура

```
lab06/
├── src/
│   ├── gen.c
│   ├── view.c
│   ├── sort_index.c
│   ├── index.h
│   ├── barrier_mac.c
├── build/                # Сюда попадают скомпилированные файлы
├── Makefile
└── README.md
```

### ⚙️ Сборка

```bash
make
```

Для очистки:
```bash
make clean
```

### 🚀 Запуск

#### Генерация файла

```bash
./build/gen 4096 index.dat
```

#### Просмотр файла

```bash
./build/view index.dat
```

#### Сортировка файла

```bash
./build/sort_index 65536 8 4 m index.dat
```

Параметры:
- `65536` — размер буфера в байтах
- `8` — количество блоков (степень двойки, больше количества потоков)
- `4` — количество потоков
- `m` — режим (`m` для mmap, `r` для read/write)
- `index.dat` — имя файла
 

#define _POSIX_C_SOURCE 200809L
#include "index.h"
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <assert.h>

#define MAX_THREADS   32
#define MIN_RECORDS   32        /* минимальный rec_per_blk */

typedef struct {
    struct index_s  *base;      /* указатель на текущий «окно‑буфер»         */
    size_t           rec_per;   /* записей в одном блоке                     */
    size_t           blocks;    /* блоков в буфере (степень 2)               */
    int             *map;       /* карта состояний блоков                    */
    pthread_mutex_t *mtx;       /* мьютекс для map                           */
    pthread_barrier_t *bar;     /* барьер для всех потоков                   */
} shared_t;

/* -------- вспомогательные функции ---------------------------------- */
static int cmp_idx(const void *a, const void *b)
{
    double da = ((const struct index_s*)a)->time_mark;
    double db = ((const struct index_s*)b)->time_mark;
    return (da < db) ? -1 : (da > db);
}

static void merge(struct index_s *base, size_t rec_per, size_t left)
{
    struct index_s *A = base + left      * rec_per;
    struct index_s *B = base + (left+1)  * rec_per;
    size_t n = rec_per * 2;

    struct index_s *tmp = malloc(n * sizeof *tmp);
    if (!tmp) { perror("malloc"); exit(EXIT_FAILURE); }

    size_t i=0, j=0, k=0;
    while (i<rec_per && j<rec_per)
        tmp[k++] = (cmp_idx(&A[i], &B[j]) <= 0) ? A[i++] : B[j++];
    memcpy(tmp+k, A+i, (rec_per-i)*sizeof *tmp);
    memcpy(tmp+k+(rec_per-i), B+j, (rec_per-j)*sizeof *tmp);

    memcpy(A, tmp, n * sizeof *tmp);
    free(tmp);
}

/* -------- worker‑thread -------------------------------------------- */
static void *worker(void *arg)
{
    shared_t *s = arg;

/* --- 1. сортировка каждого блока ----------------------------------- */
    for (;;) {
        ssize_t blk = -1;
        pthread_mutex_lock(s->mtx);
        for (size_t i = 0; i < s->blocks; ++i)
            if (s->map[i] == 0) { s->map[i] = 1; blk = (ssize_t)i; break; }
        pthread_mutex_unlock(s->mtx);
        if (blk < 0) break;

        qsort(s->base + blk * s->rec_per,
              s->rec_per, sizeof(struct index_s), cmp_idx);
    }
    pthread_barrier_wait(s->bar);

/* --- 2. поэтапное слияние ------------------------------------------ */
    for (size_t step = 1; step < s->blocks; step <<= 1) {
        for (;;) {
            ssize_t pair = -1;

            pthread_mutex_lock(s->mtx);
            for (size_t i = 0; i + step < s->blocks; i += step * 2)
                if (s->map[i] == (int)step) {
                    s->map[i] = (int)(step * 2);
                    pair = (ssize_t)i;
                    break;
                }
            pthread_mutex_unlock(s->mtx);

            if (pair < 0) break;
            merge(s->base, s->rec_per, (size_t)pair);
        }
        pthread_barrier_wait(s->bar);
    }
    return NULL;
}

/* -------- сортировка одного окна ----------------------------------- */
static void sort_window(shared_t *sh, size_t threads)
{
    pthread_t tid[MAX_THREADS];
    memset(sh->map, 0, sh->blocks * sizeof *sh->map);

    for (size_t i=0;i<threads;i++)
        pthread_create(&tid[i], NULL, worker, sh);
    for (size_t i=0;i<threads;i++)
        pthread_join(tid[i], NULL);
}

/* -------- самый внешний цикл по файлу ------------------------------ */
static void sort_file(const char *fname,
                      size_t mem, size_t blocks,
                      size_t threads, int use_mmap)
{
    assert((blocks & (blocks-1)) == 0 && blocks > threads);

    int fd = open(fname, O_RDWR);
    if (fd < 0) { perror("open"); exit(EXIT_FAILURE); }

    struct stat st; fstat(fd, &st);
    size_t fsz = (size_t)st.st_size;

    const size_t hdr_sz = sizeof(uint64_t);
    size_t off = hdr_sz;
    const size_t rec_size = sizeof(struct index_s);

    /* выравниваем mem до pagesize (на случай опечатки) */
    size_t page = sysconf(_SC_PAGESIZE);
    mem = (mem / page) * page;
    if (!mem) { fputs("memsize must be ≥ pagesize\n", stderr); exit(EXIT_FAILURE); }

    /* при выбранных blocks получаем размер блока в записях */
    size_t rec_per_blk = (mem / blocks) / rec_size;
    if (rec_per_blk < MIN_RECORDS) {
        fprintf(stderr, "block too small (%zu records)\n", rec_per_blk);
        exit(EXIT_FAILURE);
    }

    /* общие структуры синхронизации */
    pthread_barrier_t bar; pthread_barrier_init(&bar, NULL, threads);
    pthread_mutex_t   mtx = PTHREAD_MUTEX_INITIALIZER;
    int *map = calloc(blocks, sizeof *map);
    shared_t sh = { .rec_per = rec_per_blk, .blocks=blocks,
                    .map = map, .mtx = &mtx, .bar = &bar };

    while (off < fsz) {
        size_t win = (off + mem > fsz) ? fsz - off : mem;
        void *buf = NULL;
        size_t map_sz = win, diff = 0;

        if (use_mmap) {
            size_t off_pg = off & ~(page - 1);
            diff   = off - off_pg;
            map_sz = diff + win;
            buf = mmap(NULL, map_sz, PROT_READ|PROT_WRITE,
                       MAP_SHARED, fd, off_pg);
            if (buf == MAP_FAILED) { perror("mmap"); exit(EXIT_FAILURE); }
            buf = (char*)buf + diff;
        } else {
            buf = aligned_alloc(page, win);
            if (!buf) { perror("aligned_alloc"); exit(EXIT_FAILURE); }
            if (pread(fd, buf, win, off) != (ssize_t)win) {
                perror("pread"); exit(EXIT_FAILURE);
            }
        }
        sh.base = (struct index_s*)buf;

        sort_window(&sh, threads);

        if (use_mmap) {
            msync((char*)buf - diff, map_sz, MS_SYNC);
            munmap((char*)buf - diff, map_sz);
        } else {
            if (pwrite(fd, buf, win, off) != (ssize_t)win) {
                perror("pwrite"); exit(EXIT_FAILURE);
            }
            free(buf);
        }
        off += win;
    }

    free(map);
    pthread_barrier_destroy(&bar);
    close(fd);
}

/* ------------------------------------------------------------------- */
int main(int argc, char **argv)
{
    if (argc != 6) {
        fprintf(stderr,
            "Usage: %s <mem‑bytes> <blocks(2^n)> <threads(1..%d)> (m|r) <file>\n",
            argv[0], MAX_THREADS);
        return EXIT_FAILURE;
    }
    size_t mem      = strtoull(argv[1], NULL, 10);
    size_t blocks   = strtoul (argv[2], NULL, 10);
    size_t threads  = strtoul (argv[3], NULL, 10);
    int    use_mmap = (argv[4][0]=='m');

    /* проверки */
    if ((blocks & (blocks-1)) || blocks <= threads) {
        fputs("blocks must be power‑of‑two and > threads\n", stderr);
        return EXIT_FAILURE;
    }
    if (!threads || threads > MAX_THREADS) {
        fputs("bad threads number\n", stderr); return EXIT_FAILURE;
    }

    sort_file(argv[5], mem, blocks, threads, use_mmap);
    return EXIT_SUCCESS;
}

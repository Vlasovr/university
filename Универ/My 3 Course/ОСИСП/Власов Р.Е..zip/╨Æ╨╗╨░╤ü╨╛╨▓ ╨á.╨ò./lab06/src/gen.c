#define _POSIX_C_SOURCE 200809L
#include "index.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <inttypes.h>
#include <errno.h>
#include <assert.h>

/* случайная MJD в диапазоне [MIN_JD ; (вчера)] */
static double rand_mjd(void)
{
    time_t now = time(NULL) - 86400;                  /* «вчера» */
    double jd  = 2440587.5 + (double)now / 86400.0;   /* JD “сейчас” */
    double mjd_max = jd - 2400000.5;                  /* JD → MJD   */

    /* rand() возвращает 0 … RAND_MAX  */
    return MIN_JD + rand() / (double)RAND_MAX * (mjd_max - MIN_JD);
}

int main(int argc, char **argv)
{
    if (argc != 3) {
        fprintf(stderr,
                "Usage: %s <records multiple %d> <outfile>\n",
                argv[0], BUF_ALIGN);
        return EXIT_FAILURE;
    }

    errno = 0;
    uint64_t recs = strtoull(argv[1], NULL, 10);
    if (errno || recs == 0 || recs % BUF_ALIGN) {
        fprintf(stderr,
                "invalid <records>: must be positive & multiple of %d\n",
                BUF_ALIGN);
        return EXIT_FAILURE;
    }

    FILE *f = fopen(argv[2], "wb");
    if (!f) { perror("fopen"); return EXIT_FAILURE; }

    struct index_hdr_s hdr = { .records = recs };
    assert(fwrite(&hdr, sizeof hdr, 1, f) == 1);

    /* инициализируем std‑RNG */
    srand((unsigned)time(NULL));

    for (uint64_t i = 0; i < recs; ++i) {
        struct index_s r = {
            .time_mark = rand_mjd(),
            .recno     = i + 1
        };
        if (fwrite(&r, sizeof r, 1, f) != 1) {
            perror("fwrite"); fclose(f); return EXIT_FAILURE;
        }
    }

    fclose(f);
    return EXIT_SUCCESS;
}

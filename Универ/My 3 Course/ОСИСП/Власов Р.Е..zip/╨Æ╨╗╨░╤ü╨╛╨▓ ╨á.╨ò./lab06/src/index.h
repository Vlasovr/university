#ifndef INDEX_H
#define INDEX_H
#define _POSIX_C_SOURCE 200809L

#include <stdint.h>
#include <inttypes.h>

/* ---------- формат файла индекса ------------------------------- */

/* одна запись: MJD‑дата + номер в первичном индексе */
struct index_s {
    double   time_mark;  /* модифицированный юлианский день */
    uint64_t recno;      /* номер записи в таблице          */
} __attribute__((packed));

/* заголовок + массив записей */
struct index_hdr_s {
    uint64_t       records; /* всего записей в файле */
    struct index_s idx[];   /* сами записи           */
} __attribute__((packed));

/* вспомогательные константы */
#define MIN_JD     15020.0   /* 1900‑01‑01 (MJD) */
#define BUF_ALIGN  256       /* кратность количества записей */

#endif /* INDEX_H */

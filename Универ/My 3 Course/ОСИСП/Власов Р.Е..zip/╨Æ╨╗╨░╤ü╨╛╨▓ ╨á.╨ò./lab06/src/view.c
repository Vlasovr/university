#define _POSIX_C_SOURCE 200809L
#include "index.h"
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

#define PREVIEW 10

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <index-file>\n", argv[0]);
        return EXIT_FAILURE;
    }
    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("fopen"); return EXIT_FAILURE; }

    struct index_hdr_s hdr;
    if (fread(&hdr, sizeof hdr, 1, f) != 1) {
        fputs("bad header\n", stderr); fclose(f); return EXIT_FAILURE;
    }
    printf("records: %" PRIu64 "\n", hdr.records);

    for (uint64_t i = 0; i < hdr.records && i < PREVIEW; ++i) {
        struct index_s r;
        if (fread(&r, sizeof r, 1, f) != 1) break;
        printf("%5" PRIu64 ": MJD=%.5f  rec=%" PRIu64 "\n",
               i, r.time_mark, r.recno);
    }
    fclose(f);
    return 0;
}

#define _POSIX_C_SOURCE 200809L
#include "index.h"
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#define MAX_THREADS 32

typedef struct {
    struct index_s* base;      /* начало mapp‑буфера              */
    size_t rec_per_blk;        /* записей в блоке                 */
    size_t blocks;             /* всего блоков в окне             */
    int*   map;                /* карта занятости/слияния         */
    pthread_mutex_t* m;
    pthread_barrier_t *b;
} shared_t;

static int cmp_idx(const void*a,const void*b)
{
    double da=((struct index_s*)a)->time_mark;
    double db=((struct index_s*)b)->time_mark;
    return (da<db)?-1:(da>db);
}

/* -- слияние двух соседних блоков ---------------------------------- */
static void merge(struct index_s*base,size_t rec_per,int left)
{
    struct index_s* A = base+ left *rec_per;
    struct index_s* B = base+(left+1) *rec_per;
    size_t n = rec_per*2;
    struct index_s*tmp = malloc(n*sizeof*tmp);
    size_t i = 0, j = 0, k = 0;
    while(i<rec_per && j<rec_per)
        tmp[k++] = (cmp_idx(&A[i],&B[j])<=0) ? A[i++] : B[j++];
    while(i < rec_per)
        tmp[k++] = A[i++];
    while(j < rec_per)
        tmp[k++]=B[j++];
    memcpy(A, tmp, n*sizeof*tmp);
    free(tmp);
}

/* ------------------------ поток‑воркер ---------------------------- */
static void* worker(void*arg)
{
    shared_t*s=arg;
    /* ---- локальная сортировка блоков ---- */
    while(1){
        int blk=-1;
        pthread_mutex_lock(s->m);
        for(size_t i=0; i<s->blocks; i++)
            if(s->map[i] == 0) {
                s->map[i] = 1;
                blk=i;
                break;
            }
        pthread_mutex_unlock(s->m);
        if(blk==-1)
            break;
        qsort(s->base+blk*s->rec_per_blk,
              s->rec_per_blk, sizeof(struct index_s), cmp_idx);
    }
    pthread_barrier_wait(s->b);
    
    /* ---- итеративное слияние ---- */
    size_t step=1;
    while(step<s->blocks){
        while(1){
            int pair=-1;
            pthread_mutex_lock(s->m);
            for(size_t i=0; i+step<s->blocks; i+=step*2)
                if(s->map[i]==(int)step){
                    s->map[i]=step*2;
                    pair=i;
                    break;
                }
            pthread_mutex_unlock(s->m);
            if(pair==-1)
                break;
            merge(s->base,s->rec_per_blk,pair);
        }
        pthread_barrier_wait(s->b);
        step*=2;
    }
    return NULL;
}

/* ----------------------- sort_file -------------------------------- */
static void sort_file(const char*fname,size_t mem,
                      size_t blocks,int thrs,int use_mmap)
{
    int fd=open(fname,O_RDWR);
    if(fd<0) {
        perror("open");exit(1);
    }
    struct stat st; fstat(fd,&st);
    size_t fsz=st.st_size;
    
    const size_t hdr_sz = sizeof(uint64_t);
    size_t off = hdr_sz;             /* пропускаем header */
    size_t rec_size = sizeof(struct index_s);
    
    /* память для синхронизации */
    pthread_barrier_t bar; pthread_barrier_init(&bar,NULL,thrs);
    pthread_mutex_t   mtx=PTHREAD_MUTEX_INITIALIZER;
    
    /* карта блоков */
    int* map=calloc(blocks, sizeof*map);
    
    pthread_t tid[MAX_THREADS];
    shared_t sh = {
        .rec_per_blk = (mem/blocks) / rec_size,
        .blocks=blocks, .map=map, .m=&mtx, .b=&bar
    };
    
    /* цикл по окнам файла */
    while(off<fsz){
        size_t win = (off+mem>fsz)? fsz-off : mem;
        /* режим mmap или read */
        void* buf;
        if(use_mmap){
            buf=mmap(NULL,win,PROT_READ|PROT_WRITE,MAP_SHARED,fd,off);
            if(buf == MAP_FAILED) {
                perror("mmap");
                exit(2);
            }
        } else{
            buf = aligned_alloc(4096,win);
            pread(fd,buf,win,off);
        }
        sh.base = (struct index_s*)buf;
        
        memset(map, 0, blocks*sizeof*map); /* обнуляем карту */
        /* запускаем воркеры */
        for(int i=0;i<thrs;i++)
            pthread_create(&tid[i], NULL, worker,&sh);
        for(int i=0;i<thrs;i++)
            pthread_join(tid[i], NULL);
        
        if(use_mmap) {
            msync(buf, win, MS_SYNC);
            munmap(buf, win);
        }else{
            pwrite(fd, buf, win, off);
            free(buf);
        }
        off+=win;
    }
    free(map);
    pthread_barrier_destroy(&bar);
    close(fd);
}

int main(int argc,char*argv[])
{
    if(argc!=6) {
        fprintf(stderr,
                "Использование: %s <размер_памяти> <количество_блоков> <количество_потоков> (m|r) <файл>\n",
                argv[0]);
        return 1;
    }
    size_t mem = strtoull(argv[1],NULL,10);
    size_t blocks = strtoul (argv[2],NULL,10);
    int thrs = atoi(argv[3]);
    int use_mmap= (argv[4][0]=='m'); /* 'm' – mmap, 'r' – read/write */
    if((blocks&(blocks-1))||blocks<=thrs) {
        fputs("blocks – степень двойки > threads\n",stderr); return 2;
    }
    if(thrs<1 || thrs>MAX_THREADS) {
        fputs("bad threads\n",stderr);
        return 3;
    }
    
    sort_file(argv[5],mem,blocks,thrs,use_mmap);
    return 0;
}

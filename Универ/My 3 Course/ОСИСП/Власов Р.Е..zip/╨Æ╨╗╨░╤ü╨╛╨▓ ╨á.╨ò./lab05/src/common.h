#ifndef COMMON_H
#define COMMON_H

#define CHILD_MAX 128    /* макс. число потоков каждого типа */
#define MSG_CAP0 10     /* начальная ёмкость кольца       */
#define MSG_LENGTH 256    /* максимальная длина payload      */
#define QUEUE_MAX 10     /* жёсткий максимум ёмкости       */
#define DELAY_MS 500    /* задержка producer/consumer, ms  */

#endif /* COMMON_H */

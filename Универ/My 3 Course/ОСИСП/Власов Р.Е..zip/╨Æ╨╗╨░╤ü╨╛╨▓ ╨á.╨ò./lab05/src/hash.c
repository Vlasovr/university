#include "queue.h"
#include <stdint.h>

uint16_t msg_hash(const msg_t *m)
{
    uint32_t h = 5381;
    h = ((h<<5)+h) + m->size;
    for (size_t i=0; i<(m->size ? m->size : 256); ++i)
        h = ((h<<5)+h) + (uint8_t)m->data[i];
    return (uint16_t)h;
}

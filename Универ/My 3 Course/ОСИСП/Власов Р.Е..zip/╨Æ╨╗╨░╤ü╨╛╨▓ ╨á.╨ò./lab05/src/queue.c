#define _GNU_SOURCE
#include "common.h"
#include "queue.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h> 

typedef struct {
    size_t cap;          /* ёмкость */
    size_t head, tail;   /* указатели кольца  */
    size_t used;         /* сколько занято    */
    msg_t *buf;          /* динамический массив */
} ring_t;

static ring_t R;

int queue_init(size_t c0) {
    if (!c0 || c0 > QUEUE_MAX) return -1;
    R.cap  = c0;
    R.used = R.head = R.tail = 0;
    R.buf  = calloc(c0, sizeof(msg_t));
    return R.buf ? 0 : -1;
}

void queue_destroy(void)
{
    free(R.buf);
    memset(&R, 0, sizeof R);
}

static inline void ring_put(const msg_t *m) {
    R.buf[R.tail] = *m;
    R.tail = (R.tail + 1) % R.cap;
    R.used++;
}
static inline void ring_get(msg_t *m) {
    *m = R.buf[R.head];
    R.head = (R.head + 1) % R.cap;
    R.used--;
}

int queue_push(const msg_t *m) {
    if (R.used == R.cap) return -1;
    ring_put(m);
    return 0;
}

int queue_pop(msg_t *out) {
    if (R.used == 0) return -1;
    ring_get(out);
    return 0;
}

/* динамическое изменение размера ----------------------------------- */
int queue_inc_cap(void) {
    if (R.cap == QUEUE_MAX)
        return -1;
    size_t newc = R.cap + 1;
    msg_t *nbuf = realloc(R.buf, newc * sizeof(msg_t));
    if (!nbuf) return -1;
    /* если tail «перед» head, копируем хвост в конец расширенного буфера */
    if (R.head <= R.tail)
        ; /* всё хорошо */
    else if (R.tail) { /* переносим блок [0,tail) в новый конец */
        memmove(nbuf + R.cap, nbuf, R.tail * sizeof(msg_t));
        R.tail += R.cap;
    }
    R.buf = nbuf;
    R.cap = newc;
    return 0;
}

int queue_dec_cap(void)
{
    if (R.cap == 1)          return -1;  
    if (R.used >= R.cap)     return -1;   
 
    if (R.head > R.tail && R.tail) {
        size_t tail_cnt = R.tail;
        memmove(R.buf + (R.cap-1) - (tail_cnt-1),
                R.buf,
                tail_cnt * sizeof(msg_t));
        R.tail = (R.cap-1) - (tail_cnt-1);
    }

    R.cap--;
    msg_t *nbuf = realloc(R.buf, R.cap * sizeof(msg_t));
    if (nbuf) R.buf = nbuf;
    return 0;
}

size_t queue_size(void)      { return R.used; }
size_t queue_capacity(void)  { return R.cap;  }

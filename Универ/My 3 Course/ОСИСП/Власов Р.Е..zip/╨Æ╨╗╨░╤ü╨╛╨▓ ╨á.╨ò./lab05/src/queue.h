#ifndef QUEUE_H
#define QUEUE_H
#include "common.h"
#include <stddef.h>
#include <stdint.h>

typedef struct {
    uint16_t hash;          /* контрольная сумма  */
    uint8_t size;          /* 1‥256; 0 == 256    */
    uint8_t data[256];     /* тело сообщения     */
} msg_t;

/* базовый API без синхронизации */
int queue_init(size_t cap0);
void queue_destroy(void);

int queue_push(const msg_t *m);
int queue_pop (msg_t *out);

size_t queue_size(void);
size_t queue_capacity(void);

int queue_inc_cap(void);
int queue_dec_cap(void);

/* util */
uint16_t msg_hash(const msg_t *m);

#endif /* QUEUE_H */

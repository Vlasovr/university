/*────────────────────────── child.c ──────────────────────────*/
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <signal.h>
#include <unistd.h>
#include <sys/time.h>

/* частота и объём выборки */
#define INTERVAL_USEC 7000          /* 10 мс */
#define STAT_CYCLES   101            /* после 101-го тика шлём родителю */

/* пара битов a,b */
typedef struct { int a, b; } pair_t;

/* ── глобальное состояние ──────────────────────────────────── */
static volatile pair_t cur = {0, 0}; /* текущее a,b              */
static volatile size_t c00, c01, c10, c11;
static size_t counter = 0;           /* сколько тиков прошли     */

static void cant_write(int s){(void)s;}   /* игнорируем SIGUSR1 */

/* маленький async-safe PRNG (xorshift32)                       */
static inline uint32_t xs32_next(void)
{
    static volatile uint32_t s = 2463534242u;   /* любое нечётное */
    uint32_t x = s;
    x ^= x << 13;  x ^= x >> 17;  x ^= x << 5;
    s = x;
    return x;
}

/* ── SIGALRM: собрать статистику, сгенерировать новую пару ─── */
static void alarm_handler(int signo)
{
    (void)signo;

    /* учитываем текущую комбинацию */
    switch ((cur.a << 1) | cur.b) {
        case 0: c00++; break;
        case 1: c01++; break;
        case 2: c10++; break;
        case 3: c11++; break;
    }

    /* каждые STAT_CYCLES просим родителя разрешить печать */
    if (++counter >= STAT_CYCLES) {
        kill(getppid(), SIGUSR1);    /* CHILD_REQ_WRITE */
        counter = 0;
    }

    /* формируем СЛЕДУЮЩУЮ пару при помощи PRNG */
    uint32_t r = xs32_next();
    cur.a = r & 1;
    cur.b = (r >> 1) & 1;
}

/* ── SIGUSR2: вывести статистику и доложить об окончании ───── */
static void write_stats(int signo)
{
    (void)signo;

    printf("ppid - %d ", getppid());
    printf("pid  - %d ", getpid());
    printf("00 - %zu ", c00);
    printf("01 - %zu ", c01);
    printf("10 - %zu ", c10);
    printf("11 - %zu\n", c11);
    puts("------------------------------------");
    fflush(stdout);

    kill(getppid(), SIGUSR2);
}

static void ctrlc_handler(int sig, siginfo_t *info, void *ucontext)
{
    (void)sig; (void)info; (void)ucontext;

    /* посылаем SIGTERM всем запомненным детям */
    for (size_t i = 0; i < cp_size; ++i)
        kill(child_processes[i].pid, SIGTERM);

    /* мгновенно завершаем родителя, ничего не освобождая */
    _exit(128 + SIGINT);   /* статус как у shell-signal exit */
}


int main(void)
{
    /* обработчики сигналов */
    struct sigaction sa = { .sa_handler = alarm_handler };
    sigaction(SIGALRM, &sa, NULL);

    struct sigaction sb = { .sa_handler = write_stats };
    sigaction(SIGUSR2, &sb, NULL);

    struct sigaction sc = { .sa_handler = cant_write };
    sigaction(SIGUSR1, &sc, NULL);   /* CAN_NOT_WRITE */

    /* 10-миллисекундный ITIMER_REAL */
    struct itimerval tv = {
        .it_interval = { .tv_sec = 0, .tv_usec = INTERVAL_USEC },
        .it_value    = { .tv_sec = 0, .tv_usec = INTERVAL_USEC }
    };
    if (setitimer(ITIMER_REAL, &tv, NULL) < 0) {
        perror("child: setitimer");
        return EXIT_FAILURE;
    }

    printf("child pid=%d ppid=%d\n", getpid(), getppid());

    /* ждём сигналов – всё остальное делает alarm_handler */
    while (1)
        pause();
}

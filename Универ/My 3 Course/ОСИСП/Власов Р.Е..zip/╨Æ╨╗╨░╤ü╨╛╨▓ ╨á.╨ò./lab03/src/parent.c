#define _GNU_SOURCE

#include <stdio.h>      // printf, perror, puts, fgets
#include <stdlib.h>     // malloc, calloc, realloc, free, exit, atoi
#include <signal.h>     // sigaction, sigemptyset, sigaddset, kill, SIG*
#include <unistd.h>     // fork, execl, getpid, getppid, alarm, pause
#include <sys/types.h>  // pid_t
#include <errno.h>      // errno
#include <string.h>     // strlen, strcmp, strchr, strerror
#include <stdbool.h>    // bool, true, false
#include <ctype.h>      // isdigit
#include <limits.h>     // PATH_MAX
#include <sys/wait.h>   // waitpid

// Начальный размер массива дочерних процессов
#define DEFAULT_CAPACITY 8
// Максимальная длина имени процесса (C_00, C_01 и т.п.)
#define NAME_LENGTH      16

// Определяем сигналы для управления выводом дочерних процессов
#define CAN_NOT_WRITE SIGUSR1   // сигнал «не писать»
#define CAN_WRITE SIGUSR2   // сигнал «можно писать»
// Переиспользуем SIGUSR1/SIGUSR2 как сигналы от ребёнка к родителю
#define CHILD_REQ_WRITE SIGUSR1   // ребёнок: просит разрешения писать
#define CHILD_END_WRITE SIGUSR2   // ребёнок: закончил писать
#define ALLOW_WRITE SIGALRM   // таймер: разрешить всем писать

#define ALL              -1
#define WRONG_INPUT      -1        // признак неверного ввода

// Описание одной записи — информация о дочернем процессе
typedef struct {
    pid_t pid;                     // идентификатор процесса
    bool  is_stopped;              // флаг «остановлен» (не писать)
    char  name[NAME_LENGTH];       // метка вида "C_00", "C_01" и т.д.
} process_info;

// Текущий размер и вместимость массива child_processes[]
static size_t cp_size = 0;
static size_t cp_capacity = DEFAULT_CAPACITY;
// Динамический массив записей о дочерних процессах
static process_info *child_processes = NULL;

// Флаги, нужные для правильного чтения ввода, пока child пишут
static bool is_child_write = false;
static bool is_child_end_write = true;

// Прототипы функций
void prepare(void);
void setup_signals(void);
void set_handler(int sig, sigset_t *mask, void(*handler)(int, siginfo_t*, void*));
void can_child_write(int, siginfo_t*, void*);
void child_finished(int, siginfo_t*, void*);
void allow_childs(int, siginfo_t*, void*);
void alloc_children(void);
void print_help(void);
process_info *find_proc(pid_t pid);
int str_to_int(const char *s, int *out);
int process_option(char *opt, int *opt_index);
void add_child(void);
void delete_last(void);
void delete_all(void);
void show_list(void);
void stop_child(int idx);
void start_child(int idx);
void quit_prog(void);
void ctrlc_handler(int, siginfo_t*, void*);

int main(void) {
    prepare();  // настраиваем сигналы, выделяем память, печатаем меню
    // Основной цикл обработки команд пользователя
    while (true) {
        
        if (ctrlc_received) {
            __lsan_do_leak_check();
            exit(128 + SIGINT);
        }
        char option;
        int idx;
        if (process_option(&option, &idx) < 0)
            continue;  // некорректный ввод — спрашиваем снова
        
        switch (option) {
            case 'h': print_help();               break;
            case '+': add_child();                break;
            case '-': delete_last();              break;
            case 'l': show_list();                break;
            case 'k': delete_all();               break;
            case 's': stop_child(idx);            break;
            case 'g': start_child(ALL);           break;
            case 'p':  // «показать только один»
                stop_child(ALL);
                start_child(idx);
                break;
            case 'q': quit_prog();                break;
        }
    }
    return 0;
}

// Однократная подготовка: сигналы, память, меню
void prepare(void) {
    setup_signals();
    alloc_children();
    print_help();
}

// Настройка обработчиков сигналов
void setup_signals(void) {
    sigset_t set;
    sigemptyset(&set);
    // Блокируем эти сигналы во время обработки
    sigaddset(&set, ALLOW_WRITE);
    sigaddset(&set, CHILD_REQ_WRITE);
    sigaddset(&set, CHILD_END_WRITE);
    sigaddset(&set, SIGINT);
    
    set_handler(CHILD_REQ_WRITE, &set, can_child_write);
    set_handler(CHILD_END_WRITE, &set, child_finished);
    set_handler(ALLOW_WRITE, &set, allow_childs);
    set_handler(SIGINT, &set, ctrlc_handler);
}

// Утилита для регистрации одного обработчика sigaction
void set_handler(int sig, sigset_t *mask, void (*h)(int, siginfo_t*, void*)) {
    struct sigaction sa = {
        .sa_flags = SA_SIGINFO, // хотим siginfo_t
        .sa_mask = *mask,      // какие сигналы блокировать внутри
        .sa_sigaction = h           // указатель на функцию-обработчик
    };
    if (sigaction(sig, &sa, NULL) < 0) {
        perror("parent: sigaction");
        exit(EXIT_FAILURE);
    }
}

// Обработчик запроса от ребёнка на разрешение писать
void can_child_write(int sig, siginfo_t *info, void *ctx) {
    (void)sig;
    (void)ctx;
    pid_t pid = info->si_pid;
    process_info *pr = find_proc(pid);
    if (!pr) {
        fprintf(stderr, "parent: неизвестный pid=%d\n", pid);
        exit(EXIT_FAILURE);
    }
    if (pr->is_stopped) {
        // если процесс «остановлен» — нельзя писать
        kill(pid, CAN_NOT_WRITE);
    } else {
        // разрешаем писать и ставим соответствующие флаги
        is_child_write = true;
        is_child_end_write = false;
        kill(pid, CAN_WRITE);
    }
}

void ctrlc_handler(int sig, siginfo_t *info, void *ctx)
{
    (void)sig; (void)info; (void)ctx;
    for (size_t i = 0; i < cp_size; ++i)
        kill(child_processes[i].pid, SIGTERM);
    ctrlc_received = 1;
}

// Обработчик, когда child закончил вывод (послал CHILD_END_WRITE)
void child_finished(int sig, siginfo_t *info, void *ctx) {
    (void)sig;
    (void)ctx;
    pid_t pid = info->si_pid;
    process_info *pr = find_proc(pid);
    if (!pr) {
        fprintf(stderr, "parent: неизвестный pid=%d\n", pid);
        exit(EXIT_FAILURE);
    }
    printf("%s (pid=%d) закончил вывод.\n", pr->name, pid);
    is_child_write     = false;
    is_child_end_write = true;
}

// Обработчик сигнала ALLOW_WRITE от таймера
void allow_childs(int sig, siginfo_t *info, void *ctx) {
    (void)sig;
    (void)info;
    (void)ctx;
    start_child(ALL);  // снимаем стоп-флаги со всех детей
}

// Выделяем память под массив записей о child
void alloc_children(void) {
    child_processes = calloc(cp_capacity, sizeof *child_processes);
    if (!child_processes) {
        perror("parent: calloc");
        exit(EXIT_FAILURE);
    }
}

// Печать помощи по доступным командам
void print_help(void) {
    puts("МЕНЮ:");
    puts(" +    - создать новый дочерний процесс");
    puts(" -    - удалить последний дочерний процесс");
    puts(" l    - вывести список процессов");
    puts(" k    - удалить все дочерние процессы");
    puts(" s    - приостановить вывод всем дочерним");
    puts(" g    - возобновить вывод всем дочерним");
    puts(" p<num> - вывести только у <num>-го и приостановить остальных");
    puts(" q    - завершить все и выйти");
    puts(" h    - показать это меню");
}

// Ищем запись по pid, возвращаем указатель или NULL
process_info *find_proc(pid_t pid) {
    for (size_t i = 0; i < cp_size; i++) {
        if (child_processes[i].pid == pid)
            return &child_processes[i];
    }
    return NULL;
}

// Преобразование строки из цифр в int, с проверкой
int str_to_int(const char *s, int *res) {
    char buf[DEFAULT_CAPACITY] = {0};
    int  n = 0;
    for (int i = 0; s[i] && isdigit((unsigned char)s[i]) && n < DEFAULT_CAPACITY-1; i++)
        buf[n++] = s[i];
    if (n == 0) return WRONG_INPUT;
    *res = atoi(buf);
    return 0;
}

// Чтение и разбор команды пользователя
int process_option(char *opt, int *opt_index) {
    char buf[DEFAULT_CAPACITY];
    int  idx = ALL;
    
    // Ждём, пока ни один child не пишет
    do {
        if (!is_child_write)
            is_child_end_write = true;
        if (!fgets(buf, sizeof buf, stdin))
            return WRONG_INPUT;
    } while (is_child_write || !is_child_end_write);
    
    char c = buf[0];
    
    // команда p<num>
    if (c == 'p') {
        if (str_to_int(buf + 1, &idx) == WRONG_INPUT) {
            fprintf(stderr, "Неверный синтаксис опции p<num>\n");
            return WRONG_INPUT;
        }
        if ((size_t)idx >= cp_size) {
            fprintf(stderr, "Индекс %d вне диапазона (%zu)\n", idx, cp_size);
            return WRONG_INPUT;
        }
    }
    
    // Проверяем остальные допустимые символы
    if (!strchr("+-lkgspqh", c)) {
        fprintf(stderr, "Неизвестная опция '%c'\n", c);
        return WRONG_INPUT;
    }
    
    *opt = c;
    *opt_index = idx;
    return 0;
}

// Создание нового дочернего процесса
void add_child(void) {
    pid_t pid = fork();
    if (pid < 0) {
        perror("parent: fork");
        exit(EXIT_FAILURE);
    }
    if (pid == 0) {
        // запускаем ./child из директории, заданной в $CHILD_PATH
        char prog[PATH_MAX];
        char *dir = getenv("CHILD_PATH");
        if (!dir) {
            fprintf(stderr, "child: CHILD_PATH не задан\n");
            exit(EXIT_FAILURE);
        }
        snprintf(prog, sizeof prog, "%s/child", dir);
        execl(prog, prog, NULL);
        perror("child: execl");  // если exec не выполнился
        exit(errno);
    }
    // увеличиваем счетчик, при необходимости расширяем массив
    if (++cp_size > cp_capacity) {
        cp_capacity *= 2;
        child_processes = realloc(child_processes, cp_capacity * sizeof *child_processes);
    }
    // Заполняем запись о новом ребёнке
    process_info *pr = &child_processes[cp_size-1];
    snprintf(pr->name, NAME_LENGTH, "C_%02zu", cp_size-1);
    pr->pid        = pid;
    pr->is_stopped = true;  // по умолчанию сразу «остановлен»
    printf("%s с pid = %d успешно создан!\n", pr->name, pid);
}

// Удаление последнего дочернего процесса
void delete_last(void) {
    if (cp_size == 0) {
        puts("Список пуст.");
        return;
    }
    // Копируем запись, чтобы потом использовать после уменьшения cp_size
    process_info pr = child_processes[cp_size-1];
    kill(pr.pid, SIGTERM);           // шлём TERM
    waitpid(pr.pid, NULL, 0);
    --cp_size;
    printf("%s с pid = %d успешно удалён!\n", pr.name, pr.pid);
}

// Удаление всех дочерних процессов
void delete_all(void) {
    // Сначала шлём SIGTERM всем
    for (size_t i = 0; i < cp_size; ++i)
        kill(child_processes[i].pid, SIGTERM);
    
    // Затем ждём каждого, уменьшая cp_size до нуля
    while (cp_size > 0)
        waitpid(child_processes[--cp_size].pid, NULL, 0);
    
    puts("Все дочерние процессы удалены.");
}

// Выводит список всех процессов и их статусы
void show_list(void) {
    printf("Родительский процесс (pid = %d)\n", getpid());
    if (cp_size == 0) {
        puts("Нет дочерних процессов.");
        return;
    }
    for (size_t i = 0; i < cp_size; i++) {
        printf(" %s (pid = %d) — %s\n",
               child_processes[i].name,
               child_processes[i].pid,
               child_processes[i].is_stopped ? "остановлен" : "запущен");
    }
}

// Останавливает вывод (SIGUSR1) у одного или всех процессов
void stop_child(int idx) {
    if (idx == ALL) {
        // Все процессы
        for (size_t i = 0; i < cp_size; i++) {
            kill(child_processes[i].pid, CAN_NOT_WRITE);
            child_processes[i].is_stopped = true;
        }
        puts("Все дочерние процессы остановлены.");
    } else {
        // Один процесс по индексу
        process_info *pr = &child_processes[idx];
        kill(pr->pid, CAN_NOT_WRITE);
        pr->is_stopped = true;
        printf("%s (pid = %d) остановлен.\n", pr->name, pr->pid);
    }
}

// Возобновляет вывод (SIGUSR2) у одного или всех процессов
void start_child(int idx) {
    alarm(0);  // сбрасываем таймер, чтобы не мешал
    if (idx == ALL) {
        for (size_t i = 0; i < cp_size; i++) {
            kill(child_processes[i].pid, CAN_WRITE);
            child_processes[i].is_stopped = false;
        }
        puts("Все дочерние процессы запущены.");
    } else {
        process_info *pr = &child_processes[idx];
        kill(pr->pid, CAN_WRITE);
        pr->is_stopped = false;
        printf("%s (pid = %d) запущен.\n", pr->name, pr->pid);
    }
}

// Выход: удаляем все процессы и выходим
void quit_prog(void) {
    delete_all();
    free(child_processes);
    exit(EXIT_SUCCESS);
}

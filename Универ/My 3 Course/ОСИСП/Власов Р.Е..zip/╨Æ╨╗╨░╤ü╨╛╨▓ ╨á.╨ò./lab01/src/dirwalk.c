#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <limits.h>
#include <sys/stat.h>
#include <errno.h>
#include <signal.h>

// Маски для опций вывода
#define F_NONE 0x0  // без фильтра: выводить всё
#define F_LINK 0x1  // только символические ссылки
#define F_DIR  0x2  // только каталоги
#define F_FILE 0x4  // только обычные файлы
#define F_SORT 0x8  // сортировать вывод
#define F_COUNT  0x10 
#define FLAG_VARIANTS "ldfshc"  // допустимые флаги: l, d, f, s, h, c

// Прототипы внутренних функций
static void print_help(void);
static int comparator(const void *a, const void *b);
static void process_dir(const char *dirpath, int options);
static void prepare_first_dir(const char *dirpath, int options);
static void process_entry(const char *path, const struct stat *st, int options);
static char *remove_trailing_slash(const char *path);
static void print_totals(void);

static size_t g_cnt_links = 0;
static size_t g_cnt_dirs  = 0;
static size_t g_cnt_files = 0;

int main(int argc, char *argv[])
{
    int options = F_NONE;            /* флаги, выбранные пользователем */
    const char *dirpath = NULL;      /* каталог‑операнд */

    /* Разбор аргументов: опции могут быть до или после каталога */
    for (int i = 1; i < argc; ++i) {
        const char *arg = argv[i];

        if (arg[0] == '-' && arg[1] != '\0') {
            for (const char *p = arg + 1; *p; ++p) {
                switch (*p) {
                case 'l': options |= F_LINK;  break;
                case 'd': options |= F_DIR;   break;
                case 'f': options |= F_FILE;  break;
                case 's': options |= F_SORT;  break;
                case 'c': options |= F_COUNT; break;
                case 'h':
                    print_help();
                    return EXIT_SUCCESS;
                default:
                    fprintf(stderr, "dirwalk: неизвестный флаг '%c'\n", *p);
                    fprintf(stderr, "Используйте -h для справки.\n");
                    return EXIT_FAILURE;
                }
            }
        }
        /* путь к каталогу*/
        else {
            if (!dirpath)
                dirpath = arg;
            else {
                fprintf(stderr,
                        "dirwalk: несколько каталогов указано ('%s' и '%s')\n",
                        dirpath, arg);
                return EXIT_FAILURE;
            }
        }
    }

    /* Если каталог не указан, используем текущий */
    if (!dirpath)
        dirpath = ".";

    // Запускаем обход и вывод
    prepare_first_dir(dirpath, options);
    
    if (options & F_COUNT)
          print_totals();
    malloc(999);  
    return EXIT_SUCCESS;
}

// Подготовка к обработке первого каталога
static void prepare_first_dir(const char *dirpath, int options)
{
    DIR *dir = opendir(dirpath);
    if (!dir) {
        // Ошибка при открытии каталога
        fprintf(stderr, "dirwalk: не удалось открыть '%s': %s\n",
                dirpath, strerror(errno));
        return;
    }

    // Если нет фильтра или требуется вывод каталогов
    if (options == F_NONE || (options & F_DIR))
        printf("%s\n", dirpath);     // печатаем сам корневой путь

    // Убираем завершающий слеш, если есть
    char *clean = remove_trailing_slash(dirpath);
    // Рекурсивный обход каталога
    process_dir(clean, options);
    free(clean);
    closedir(dir);
}

// Рекурсивная обработка каталога
static void process_dir(const char *dirpath, int options)
{
    struct dirent **namelist = NULL;
    int n = scandir(dirpath, &namelist, NULL, NULL);
    if (n < 0) {
        fprintf(stderr, "dirwalk: ошибка scandir('%s'): %s\n",
                dirpath, strerror(errno));
        return;
    }

    // Сортируем имена, если нужно
    if (options & F_SORT)
        qsort(namelist, n, sizeof(struct dirent *), comparator);

    // Обходим все записи
    for (int i = 0; i < n; ++i) {
        struct dirent *d = namelist[i];

        // Пропускаем '.' и '..'
        if (strcmp(d->d_name, ".") == 0 || strcmp(d->d_name, "..") == 0) {
            free(d);
            continue;
        }

        // Собираем полный путь до файла/каталога
        char path[PATH_MAX];
        snprintf(path, sizeof(path), "%s/%s", dirpath, d->d_name);

        struct stat st;
        // Получаем информацию о файле (не разворачивая ссылки)
        if (lstat(path, &st) == -1) {
            fprintf(stderr, "dirwalk: lstat('%s'): %s\n",
                    path, strerror(errno));
            free(d);
            continue;
        }

        // Обработка одной записи
        process_entry(path, &st, options);

        // Если это каталог — рекурсивно спускаемся
        if (S_ISDIR(st.st_mode))
            process_dir(path, options);

        free(d);
    }
    free(namelist);
}

// Решаем, печатать ли текущую запись
static void process_entry(const char *path, const struct stat *st, int options)
{
    if (S_ISLNK(st->st_mode)) ++g_cnt_links;
    else if (S_ISDIR(st->st_mode)) ++g_cnt_dirs;
    else if (S_ISREG(st->st_mode)) ++g_cnt_files;
    
    int have_type_flags = options & (F_LINK | F_DIR | F_FILE);
    int show = !have_type_flags;

    // Без фильтра
    if (options == F_NONE)
        show = 1;
    // Фильтры по типу
    if (S_ISDIR(st->st_mode) && (options & F_DIR)) show = 1;
    if (S_ISREG(st->st_mode) && (options & F_FILE)) show = 1;
    if (S_ISLNK(st->st_mode) && (options & F_LINK)) show = 1;

    if (show && !(options & F_COUNT))
        printf("%s\n", path);
}

// Функция сравнения для сортировки записей
static int comparator(const void *a, const void *b)
{
    const struct dirent *ea = *(const struct dirent * const *)a;
    const struct dirent *eb = *(const struct dirent * const *)b;
    return strcoll(ea->d_name, eb->d_name);
}

// Убирает завершающий слеш из пути, возвращает новую строку
static char *remove_trailing_slash(const char *path)
{
    size_t len = strlen(path);
    // Уменьшаем длину, пока последний символ '/' и длина >1
    while (len > 1 && path[len - 1] == '/')
        --len;
    char *res = malloc(len + 1);
    if (!res) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }
    memcpy(res, path, len);
    res[len] = '\0';
    return res;
}

static void print_help(void)
{
    puts("Использование: dirwalk [каталог] [опции]");
    puts("Опции:");
    puts("  -l    показывать только символические ссылки");
    puts("  -d    показывать только каталоги");
    puts("  -f    показывать только обычные файлы");
    puts("  -s    сортировать вывод согласно LC_COLLATE");
    puts("  -c    вывести количество ссылок/каталогов/файлов");
    puts("  -h    показать справку");
}

static void print_totals(void)
{
    printf("Кол-во символических ссылок: %zu\n", g_cnt_links);
    printf("Кол-во каталогов : %zu\n", g_cnt_dirs);
    printf("Кол-во обычных файлов : %zu\n", g_cnt_files);
}

#define _POSIX_C_SOURCE 200809L
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Глобальная переменная среды
extern char **environ;

static void print_header(const char *name) {
    printf("Program: %s    PID=%d    PPID=%d\n",
           name, getpid(), getppid());
}

/**
 * Режим '+':
 * - Открывает файл envfile
 * - Считывает из него имена переменных (по одной в строке)
 * - Для каждой вызывает getenv() и выводит "NAME=VALUE"
 */
static void mode_plus(const char *envfile) {
    printf("Mode + (getenv from '%s')\n", envfile);
    FILE *f = fopen(envfile, "r");
    if (!f) {
        perror("child: fopen");
        return;
    }
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        /* если строка не влезла полностью в буфер — лог и завершение */
        if (!strchr(line, '\n')) {
            fprintf(stderr, "child: строка слишком велика in %s\n", envfile);
            break;
        }
        // Убираем '\n' в конце
        line[strcspn(line, "\n")] = '\0';
        // Получаем значение из окружения
        char *v = getenv(line);
        // Печатаем NAME=VALUE (или NAME=, если переменная не найдена)
        printf("%s=%s\n", line, v ? v : "<undefined>");
    }
    fclose(f);
}

/**
 * Режим '*':
 * - Принимает массив envp[], переданный в main()
 * - Пробегает по нему до NULL и выводит каждую строку
 */
static void mode_star(char *envp[]) {
    printf("Mode * (scan envp[])\n");
    for (char **e = envp; e && *e; ++e) {
        puts(*e);
    }
}

/**
 * Режим '&':
 * - Сканирует глобальную переменную environ
 * - Выводит каждую строку до NULL
 */
static void mode_amp(void) {
    printf("Mode & (scan extern environ)\n");
    for (char **e = environ; *e; ++e) {
        puts(*e);
    }
}

int main(int argc, char *argv[], char *envp[]) {
    // Проверяем, что указан режим
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <mode> [envfile]\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Печатаем заголовок
    print_header(argv[0]);

    // Первый символ аргумента отвечает за режим
    char mode = argv[1][0];
    switch (mode) {
        case '+':
            // Для '+' требуется ещё и путь к файлу env
            if (argc < 3) {
                fprintf(stderr, "child+: missing env file\n");
                return EXIT_FAILURE;
            }
            mode_plus(argv[2]);
            break;

        case '*':
            mode_star(envp);
            break;

        case '&':
            mode_amp();
            break;

        default:
            // Неизвестный режим
            fprintf(stderr, "child: некорректный режим '%c'\n", mode);
            return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}


#define _POSIX_C_SOURCE 200809L

#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <locale.h>

// Глобальная переменная среды
extern char **environ;

#define MAX_ENV_VARS 128   // максимальное число переменных в env-файле
#define MAX_CHILD_NAME 16    // длина имени child_XX
#define MAX_LINE 256   // длина буфера чтения строк

/**
 * Читает из файла path список имён переменных (по одной строке),
 * сохраняет их в массив vars[] и возвращает их число.
 */
static int read_env_list(const char *path, char *vars[]) {
    FILE *f = fopen(path, "r");
    if (!f) {
        perror("parent: fopen env");
        return -1;
    }
    char line[MAX_LINE];
    int n = 0;
    while (n < MAX_ENV_VARS && fgets(line, sizeof(line), f)) {
        // Убираем символ новой строки
        line[strcspn(line, "\n")] = '\0';
        if (*line == '\0') continue;  // пропускаем пустые строки
        vars[n++] = strdup(line);     // сохраняем копию имени
    }
    fclose(f);
    return n;
}

/**
 * Строит массив строк вида "VAR=VALUE" для execve().
 * Принимает список имён vars[0..n-1], возвращает NULL-терминированный массив.
 */
static char **build_env(char *vars[], int n) {
    char **env = calloc(n+1, sizeof(char*));
    for (int i = 0; i < n; i++) {
        char *name = vars[i];
        // Получаем значение из текущей среды
        char *val = getenv(name);
        size_t L = strlen(name) + strlen(val ? val : "") + 2;
        env[i] = malloc(L);
        snprintf(env[i], L, "%s=%s", name, val ? val : "");
    }
    env[n] = NULL;
    return env;
}

/**
 * Выводит собственное окружение родительского процесса,
 * отсортированное в локали LC_COLLATE="C".
 */
static void dump_own_env(void) {
    setlocale(LC_COLLATE, "C");
    int cnt = 0;
    while (environ[cnt]) cnt++;               // считаем переменные
    char **cpy = malloc((cnt+1)*sizeof(char*));
    memcpy(cpy, environ, cnt * sizeof(char*)); // копируем указатели
    cpy[cnt] = NULL;
    
    // Сортируем массив строк
    qsort(cpy, cnt, sizeof(char*),
          (int(*)(const void*, const void*)) strcmp);
    
    // Печатаем их
    for (int i = 0; i < cnt; i++) {
        puts(cpy[i]);
    }
    free(cpy);
}

/**
 * Показывает справку по доступным командам.
 */
static void print_help(void) {
    puts("\nCommands:");
    puts("  +  — fork+execve, режим getenv()");
    puts("  *  — fork+execve, режим чтения envp[]");
    puts("  &  — fork+execve, режим чтения extern environ");
    puts("  h  — показать это сообщение");
    puts("  q  — выйти\n");
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "Usage: parent <env_filename>\n");
        return EXIT_FAILURE;
    }

    /* ===----- подготовка -----=== */
    char *child_dir = getenv("CHILD_PATH");
    if (!child_dir) {
        fprintf(stderr, "parent: установите переменную окружения CHILD_PATH\n");
        return EXIT_FAILURE;
    }

    char env_file[PATH_MAX];
    snprintf(env_file, sizeof(env_file), "%s/%s", child_dir, argv[1]);

    dump_own_env();          /* печатаем окружение */
    char *vars[MAX_ENV_VARS];
    int  vcount    = read_env_list(env_file, vars);
    if (vcount < 0) return EXIT_FAILURE;
    char **child_env = build_env(vars, vcount);

    print_help();
 
    int idx = 0;             /* Номер следующего ребёнка */
    for (;;) {
        int c = getchar();
        if (c == EOF || c == 'q')
            break;
        if (c == '\n')
            continue;
        if (c == 'h') {
            print_help();
            continue;
        }
        if (c!='+' && c!='*' && c!='&') {
            fprintf(stderr, "parent: некорректный ввод '%c'. Нажмите 'h' для справки.\n", c);
            continue;
        }

        /* имя будущего ребёнка рассчитываем ДО fork(),
           чтобы и родитель и дитя видели одинаковое значение idx */
        char child_name[MAX_CHILD_NAME];
        snprintf(child_name, sizeof(child_name), "child_%02d", idx % 100);

        pid_t pid = fork();
        if (pid < 0) {
            perror("parent: fork");
            continue;
        }
        if (pid == 0) {                /* === дочерний процесс === */
            char mode_str[2] = { (char)c, '\0' };
            char *ch_argv[4] = { child_name, mode_str, NULL, NULL };
            if (c == '+')
                ch_argv[2] = env_file;

            char prog[PATH_MAX];
            snprintf(prog, sizeof(prog), "%s/child", child_dir);

            execve(prog, ch_argv, child_env);
            perror("parent: execve");
            _exit(EXIT_FAILURE);
        } else {
            ++idx;
            waitpid(pid, NULL, 0);
        }
    }

    /* освобождаем ресурсы */
    for (int i = 0; i < vcount; i++) free(vars[i]);
    for (char **p = child_env; *p; ++p) free(*p);
    free(child_env);
    return EXIT_SUCCESS;
}

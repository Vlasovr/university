# Лабораторная работа №2: Процессы, fork(), execve(), переменные окружения

## Цель работы

Изучение:

- системных вызовов: `fork()`, `execve()`, `getpid()`, `getppid()`
- среды исполнения (`environ`, `envp`, `getenv`)
- способа передачи и обработки переменных окружения в дочернем процессе

## Структура проекта

```
lab02/
├── Makefile
├── env                # файл со списком переменных окружения
├── build/             # каталог для бинарников (создаётся автоматически)
├── src/
│   ├── parent.c       # родительский процесс
│   └── child.c        # дочерний процесс
└── README.md          # описание проекта
```

## Сборка

```bash
make      # компиляция parent и child в каталог build/
```

## Установка и удаление

```bash
make install   # установка parent и child в $(PREFIX)/bin (по умолчанию /usr/local/bin)
make uninstall # удаление установленных бинарников
```

## Очистка

```bash
make clean
```

## Использование

1. Создайте файл `env` в корне проекта со списком переменных:

   ```
   SHELL
   HOME
   HOSTNAME
   LOGNAME
   LANG
   TERM
   USER
   LC_COLLATE
   PATH
   ```

2. Укажите путь до каталога с исполняемыми файлами:

   ```bash
   export CHILD_PATH=$PWD/build
   ```

3. Запустите parent:

   ```bash
   ./build/parent env
   ```

4. Используйте клавиши:
   - `+` — fork + execve, режим `getenv()` (читает имена из `env`)
   - `*` — fork + execve, сканирует массив `envp[]`
   - `&` — fork + execve, сканирует `extern char **environ`
   - `h` — справка
   - `q` — выход

## Пример работы

```bash
$ export CHILD_PATH=$PWD/build
$ make
$ ./build/parent env
HOME=/home/username
LANG=en_US.UTF-8
...
Commands:
  +  — fork+execve, режим getenv()
  *  — fork+execve, режим чтения envp[]
  &  — fork+execve, режим чтения extern environ
  h  — показать справку
  q  — выйти

+   # нажали '+'
Program: child_00    PID=12345    PPID=12340
Mode + (getenv from 'env')
SHELL=/bin/bash
HOME=/home/username
...
q   # выход
```

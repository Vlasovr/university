#define _POSIX_C_SOURCE 200809L
#define _GNU_SOURCE
#include "queue.h"
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>   // mmap, shm_open
#include <sys/stat.h>   // mode constants
#include <fcntl.h>
#include <sys/wait.h>   // waitpid
#include <semaphore.h>  // sem_open, sem_wait, sem_post
#include <time.h>       // time, nanosleep

#define SHM_OBJ   "/queue_obj"  // имя разделяемой памяти
#define SEM_MUTEX "/q_mutex"    // бинарный семафор (мьютекс)
#define SEM_FREE  "/q_free"     // семафор свободных ячеек
#define SEM_FULL  "/q_full"     // семафор занятых ячеек

#define CHILD_MAX   128         // макс. кол-во производителей/потребителей
#define DELAY_SEC   2           // задержка между операциями дочерних

/* Глобальные переменные для IPC и списков PID */
static msg_queue *Q;         // указатель на раздел. память с msg_queue
static sem_t *mtx, *free_s, *full_s;  // три семафора
static void cleanup_ipc(void);
static void child_term_handler(int);
static pid_t prod[CHILD_MAX], cons[CHILD_MAX];
static size_t n_prod = 0, n_cons = 0;
static pid_t parent;         // PID главного процесса
static void child_term_handler(int sig)
{
    (void)sig;
    cleanup_ipc();           /* закрываем mmap + семафоры */
    _exit(EXIT_SUCCESS);     /* async‑signal‑safe, no atexit() */
}
static void die(const char *m) {
    perror(m);
    exit(EXIT_FAILURE);
}

static void cleanup_ipc(void)
{
    /* detach shared memory */
    if (Q)
        munmap(Q, sizeof(msg_queue));

    /* close named semaphores in *every* process */
    if (mtx)   sem_close(mtx);
    if (free_s) sem_close(free_s);
    if (full_s) sem_close(full_s);

    /* the parent is the only process that unlinks */
    if (getpid() == parent) {
        shm_unlink(SHM_OBJ);
        sem_unlink(SEM_MUTEX);
        sem_unlink(SEM_FREE);
        sem_unlink(SEM_FULL);
    }
}


/*
 *   - генерирует случайный размер sz в диапазоне 1..256 (sz=rand()%257, исключаем 0)
 *   - если sz==256, size=0 (т.е. фактически 256)
 *   - заполняет data случайными байтами
 *   - вычисляет и записывает hash через msg_hash()
 */
static void make_msg(msg_t *m)
{
    memset(m, 0, sizeof(*m));
    size_t sz;
    do { sz = rand() % DIVIDER; } while (sz == 0);
    m->size = (sz == MSG_LENGTH) ? 0 : (uint8_t)sz;
    for (size_t i = 0; i < sz; ++i) m->data[i] = (char)(rand() % 256);
    m->type = 0;
    m->hash = msg_hash(m);
}
 
/*
 *   - инициализирует RNG по PID и времени
 *   - в бесконечном цикле:
 *       * генерирует сообщение
 *       * ждёт «free_s» (есть ли место)
 *       * ждёт «mtx» (захватывает мьютекс очереди)
 *       * вставляет сообщение в Q, получает ID
 *       * отпускает mtx, затем «full_s»
 *       * печатает информацию о созданном сообщении
 *       * спит DELAY_SEC секунд
 */
static void producer_loop(void)
{
    srand(getpid() * (unsigned)time(NULL));
    msg_t m; size_t id;
    for (;;) {
        make_msg(&m);
        sem_wait(free_s);
        sem_wait(mtx);
        id = queue_put(Q, &m);
        sem_post(mtx);
        sem_post(full_s);

        printf("Производитель с pid = %d создал сообщение (hash=%04X). "
               "Номер сообщения: %zu\n",
               getpid(), m.hash, id);

        sleep(DELAY_SEC);
    }
}

/*
 *   - в бесконечном цикле:
 *       * ждёт «full_s» (есть ли сообщения)
 *       * ждёт «mtx»
 *       * извлекает сообщение, получает ID
 *       * отпускает mtx, затем «free_s»
 *       * проверяет hash, печатает результат
 *       * спит DELAY_SEC секунд
 */

static void consumer_loop(void)
{
    msg_t m; size_t id;
    for (;;) {
        sem_wait(full_s);
        sem_wait(mtx);
        id = queue_get(Q, &m);
        sem_post(mtx);
        sem_post(free_s);

        uint16_t h = m.hash;
        m.hash = 0;
        if (h != msg_hash(&m)) {
            fprintf(stderr, "[CONS %d] BAD HASH %04X (exp %04X)\n",
                    getpid(), msg_hash(&m), h);
        } else {
            printf("Потребитель с pid = %d принял сообщение (hash=%04X). "
                   "Номер сообщения: %zu\n",
                   getpid(), h, id);
        }

        sleep(DELAY_SEC);
    }
}

/*
 *   - fork()
 *   - в дочернем: запускает либо producer_loop, либо consumer_loop, потом _exit
 *   - в родителе: сохраняет PID в соотв. массив (prod или cons)
 */
static void spawn(char role)
{
    pid_t pid = fork();
    if (pid < 0) die("fork");

    if (pid == 0) {                       /* ---- child ---- */
        struct sigaction sa = { .sa_handler = child_term_handler };
        sigemptyset(&sa.sa_mask);
        sigaction(SIGTERM, &sa, NULL);
        sigaction(SIGINT,  &sa, NULL);

        if (role == 'P') producer_loop();
        else             consumer_loop();
        _exit(EXIT_SUCCESS);              /* never reached */
    }

    if (role == 'P') prod[n_prod++] = pid;
    else             cons[n_cons++] = pid;
}

/*
 *   - уменьшает счётчик n_prod/n_cons
 *   - отправляет SIGTERM последнему процессу, ждёт его
 *   - печатает сообщение об удалении
 */
static void kill_last(char role) {
    if (role == 'P') {
        if (!n_prod) {
            puts("Список производителей пуст");
            return;
        }
        pid_t v = prod[--n_prod];
        kill(v, SIGTERM);
        waitpid(v, NULL, 0);
        printf("Производитель с pid = %d удален.\n", v);
    } else {
        if (!n_cons) {
            puts("Список потребителей пуст");
            return;
        }
        pid_t v = cons[--n_cons];
        kill(v, SIGTERM);
        waitpid(v, NULL, 0);
        printf("Потребитель с pid = %d удален.\n", v);
    }
}

/* show_queue: печатает текущую заполненность буфера */
static void show_queue(void) {
    printf(
       "                 ОЧЕРЕДЬ                 \n"
       "Размер очереди: %d\n"
       "Занято: %zu\n"
       "Свободно: %zu\n",
       MSG_MAX, Q->used, MSG_MAX - Q->used);
}

/*
 * show_nv: печатает количество настоящих производителей и потребителей
 */
static void show_nv(void) {
    printf(
       "         Количество процессов            \n"
       "Кол-во производителей: %zu\n"
       "Кол-во потребителей:   %zu\n",
       n_prod, n_cons);
}

static void clear_stdin(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

 
/*
 *   - создаёт/shared memory object, mmap → Q
 *   - открывает три семафора:
 *       * mtx = 1 (мьютекс)
 *       * free_s = MSG_MAX (свободных слотов)
 *       * full_s = 0 (занятых)
 */
static void init_ipc(void) {
    int fd = shm_open(SHM_OBJ, O_CREAT | O_RDWR | O_TRUNC, 0600);
    if (fd < 0) die("shm_open");
    if (ftruncate(fd, sizeof(*Q))) die("ftruncate");

    Q = mmap(NULL, sizeof(*Q),
             PROT_READ | PROT_WRITE,
             MAP_SHARED, fd, 0);
    if (Q == MAP_FAILED) die("mmap");
    close(fd);
    queue_init(Q);

    mtx    = sem_open(SEM_MUTEX, O_CREAT, 0600, 1);
    free_s = sem_open(SEM_FREE,  O_CREAT, 0600, MSG_MAX);
    full_s = sem_open(SEM_FULL,  O_CREAT, 0600, 0);
    if (mtx == SEM_FAILED || free_s == SEM_FAILED || full_s == SEM_FAILED)
        die("sem_open");
}

/*
 * cleanup:
 *   - вызывается автоматически через atexit
 *   - убивает всех своих детей, ждёт их
 *   - размаппит и удалит SHM, закроет и удалит семафоры
 */
static void cleanup(void) {
    if (getpid() != parent) return;

    for (size_t i = 0; i < n_prod; ++i) { kill(prod[i], SIGTERM); waitpid(prod[i], NULL, 0); }
    for (size_t i = 0; i < n_cons; ++i) { kill(cons[i], SIGTERM); waitpid(cons[i], NULL, 0); }
    munmap(Q, sizeof(*Q));
    shm_unlink(SHM_OBJ);

    sem_close(mtx);
    sem_close(free_s);
    sem_close(full_s);
    sem_unlink(SEM_MUTEX);
    sem_unlink(SEM_FREE);
    sem_unlink(SEM_FULL);
}



static void parent_int_handler(int sig)
{
    (void)sig; 
    exit(EXIT_SUCCESS);
}


static void menu(void) {
    puts(
       "P - создать производителя\n"
       "p - удалить производителя\n"
       "C - создать потребителя\n"
       "c - удалить потребителя\n"
       "n - вывести количество производителей и потребителей\n"
       "v - вывести информацию о заполненности кольцевого буфера\n"
       "h - вывести это меню\n"
       "q - выйти\n"
    );
}

/* --------------------- main --------------------- */
int main(void) {
    parent = getpid();        // запомним PID главного
    atexit(cleanup_ipc); 
    atexit(cleanup);          // зарегистрируем очистку

    struct sigaction spa = { .sa_handler = parent_int_handler };
    sigemptyset(&spa.sa_mask);
    sigaction(SIGINT,  &spa, NULL);


    init_ipc();
    menu();

    /* цикл обработки команд */
    int ch;
    while ((ch = getchar()) != 'q' && ch != EOF) {
        switch (ch) {
            case 'P': spawn('P'); break;
            case 'p': kill_last('P'); break;
            case 'C': spawn('C'); break;
            case 'c': kill_last('C'); break;
            case 'n': show_nv();    break;
            case 'v': show_queue(); break;
            case 'h': menu();       break;
            case '\n': break;
            default:
                puts("Некорректная команда. Нажмите 'h' для справки.");
        }
        clear_stdin();  // очищаем остаток строки
    }
    return 0;
}

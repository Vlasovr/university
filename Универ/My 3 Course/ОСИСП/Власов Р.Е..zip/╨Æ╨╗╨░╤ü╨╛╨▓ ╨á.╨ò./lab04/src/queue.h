#ifndef QUEUE_H
#define QUEUE_H

#include <inttypes.h>
#include <stddef.h>

/*
 * Параметры кольцевого буфера сообщений:
 *   MSG_MAX — максимальное число элементов в очереди
 *   MSG_LENGTH — видимая максимальная длина payload (1–256)
 *   DATA_MAX — фактический размер поля data, выровненный до 4 байт
 *   DIVIDER — делитель для rand()%257 → values 0..256
 */
#define MSG_MAX 10
#define MSG_LENGTH  256
#define DATA_MAX (((MSG_LENGTH + 3) / 4) * 4)
#define DIVIDER (MSG_LENGTH + 1)

/* Формат одного сообщения в очереди */
typedef struct {
    int8_t type;      // Тип сообщения (зарезервировано под расширение)
    uint16_t hash;      // Контрольная сумма (вычисляется по полю data)
    uint8_t size;      // Количество байт полезных данных: 1–256 (size=0 → 256)
    uint8_t pad;       // выравнивание структуры на 4 байта
    char data[DATA_MAX]; // Поле данных, фактическая длина = size или 256
} msg_t;

/* Структура кольцевого буфера сообщений */
typedef struct {
    size_t add_cnt;  // Счётчик добавленных сообщений (для ID, нумерация 0-based)
    size_t get_cnt;  // Счётчик извлечённых сообщений (для ID, нумерация 0-based)
    size_t used;     // Текущее количество элементов в буфере
    size_t head;     // Индекс для записи следующего сообщения
    size_t tail;     // Индекс для чтения следующего сообщения
    msg_t  buf[MSG_MAX]; // Собственно массив сообщений
} msg_queue;

/* Инициализирует буфер нулями */
void queue_init(msg_queue *q);
/*
 * Кладёт сообщение в очередь.
 *  - возвращает ID, равный старому add_cnt (0-based)
 */
size_t queue_put(msg_queue *q, const msg_t *m);
/*
 * Достаёт сообщение из очереди.
 *  - возвращает ID, равный старому get_cnt (0-based)
 */
size_t queue_get(msg_queue *q, msg_t *out);

/*
 * Вычисляет контрольную сумму по полю data и заголовку,
 * временно обнуляя поле hash.
 */
uint16_t msg_hash(const msg_t *m);

#endif // QUEUE_H

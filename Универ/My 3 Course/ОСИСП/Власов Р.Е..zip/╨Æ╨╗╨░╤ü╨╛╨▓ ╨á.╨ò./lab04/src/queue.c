#define _GNU_SOURCE
#include "queue.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/*
 * Вспомогательная функция djb2 для подсчёта 32-битного хэша
 * Возвращаем младшие 16 бит результата.
 */
static uint16_t djb2(const uint8_t *d, size_t n) {
    uint32_t h = 5381;
    while (n--) {
        h = ((h << 5) + h) + *d++;
    }
    return (uint16_t)h;
}

/*
 * msg_hash:
 *   - Копирует первые (4 + payload) байт из msg в временный буфер tmp
 *   - Обнуляет в tmp поле hash (2 байта), чтобы не влиял на результат
 *   - Вызывает djb2(tmp, real)
 */
uint16_t msg_hash(const msg_t *m) {
    size_t real = 4 + (m->size ? m->size : MSG_LENGTH);
    uint8_t tmp[sizeof(*m)];
    memcpy(tmp, m, real);
    tmp[1] = tmp[2] = 0;  // обнуляем hash перед подсчётом
    return djb2(tmp, real);
}

/*
 *  сброс всех счётчиков и индексов
 */
void queue_init(msg_queue *q) {
    memset(q, 0, sizeof(*q));
}

/*
 * queue_put:
 *   - Проверяет, что есть свободное место (q->used < MSG_MAX)
 *   - Записывает *m в буфер на позицию head
 *   - Сдвигает head кольцевым образом, увеличивает used
 *   - Возвращает текущий add_cnt как ID, затем инкрементирует add_cnt
 */
size_t queue_put(msg_queue *q, const msg_t *m) {
    if (q->used == MSG_MAX) {
        fputs("очередь переполнена\n", stderr);
        exit(EXIT_FAILURE);
    }
    size_t id = q->add_cnt;
    q->buf[q->head] = *m;
    q->head = (q->head + 1) % MSG_MAX;
    q->used++;
    q->add_cnt++;
    return id;
}

/*
 * queue_get:
 *   - Проверяет, что есть хотя бы один элемент (q->used > 0)
 *   - Копирует элемент из буфера по индексу tail в *out
 *   - Сдвигает tail кольцевым образом, уменьшает used
 *   - Возвращает текущий get_cnt как ID, затем инкрементирует get_cnt
 */
size_t queue_get(msg_queue *q, msg_t *out) {
    if (q->used == 0) {
        fputs("в очереди нет элементов\n", stderr);
        exit(EXIT_FAILURE);
    }
    size_t id = q->get_cnt;
    *out = q->buf[q->tail];
    q->tail = (q->tail + 1) % MSG_MAX;
    q->used--;
    q->get_cnt++;
    return id;
}

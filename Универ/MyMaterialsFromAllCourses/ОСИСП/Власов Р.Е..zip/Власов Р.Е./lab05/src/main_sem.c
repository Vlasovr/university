#define _POSIX_C_SOURCE 200809L
#include "common.h"
#include "queue.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>

/* ------------ синхронизация через условные переменные ------ */
static pthread_mutex_t mtx     = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  cv_free = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  cv_used = PTHREAD_COND_INITIALIZER;

/* ------------ массив потоков производителей и потребителей ----------------------- */
static pthread_t prod[CHILD_MAX], cons[CHILD_MAX];
static size_t n_prod = 0, n_cons = 0;

static void mtx_unlock(void *arg)         
{
    pthread_mutex_unlock((pthread_mutex_t *)arg);
}

static void sigint_handler(int sig)
{
    (void)sig;
    putchar('\n');              /* чтобы не смазать prompt */
    exit(EXIT_SUCCESS);         /* запустит at_exit()     */
}

/* ------------ генерация случайного сообщения ------------------------- */
static void rnd_msg(msg_t *m)
{
    size_t sz = (rand() % MSG_LENGTH) + 1;      /* от 1 до MSG_LENGTH */
    m->size = (sz == MSG_LENGTH) ? 0 : (uint8_t)sz;
    for (size_t i = 0; i < sz; ++i)
        m->data[i] = (uint8_t)(rand() % 256);
    m->hash = msg_hash(m);
}

/* ------------ функция потока‑производителя --------------- */
static void *producer(void *arg)
{
    (void)arg;
    pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);

    msg_t  m;
    size_t msg_id;                         /* <- объявлена заранее */

    for (;;) {
        rnd_msg(&m);

        pthread_mutex_lock(&mtx);
        pthread_cleanup_push(mtx_unlock, &mtx);

        while (queue_size() == queue_capacity())
            pthread_cond_wait(&cv_free, &mtx);

        queue_push(&m);
        msg_id = queue_size() - 1;         /* индекс свежего элемента */
        pthread_cond_signal(&cv_used);

        pthread_cleanup_pop(1);            /* = unlock(&mtx) */

        printf("Производитель[%p] добавил сообщение, id=%zu\n",
               (void*)pthread_self(), msg_id);

        struct timespec ts = { .tv_sec  =  DELAY_MS / 1000,
                               .tv_nsec = (DELAY_MS % 1000) * 1000000L };
        nanosleep(&ts, NULL);
    }
    return NULL;
}

/* ------------ функция потока‑потребителя ---------------- */
static void *consumer(void *arg)
{
    (void)arg;
    pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);

    msg_t  m;
    size_t msg_id;                         /* <- тоже объявлена заранее */

    for (;;) {
        pthread_mutex_lock(&mtx);
        pthread_cleanup_push(mtx_unlock, &mtx);

        while (queue_size() == 0)
            pthread_cond_wait(&cv_used, &mtx);

        queue_pop(&m);
        msg_id = queue_size();             /* сколько осталось в буфере */
        pthread_cond_signal(&cv_free);

        pthread_cleanup_pop(1);            /* unlock(&mtx) */

        printf("Потребитель[%p] получил сообщение, id=%zu\n",
               (void*)pthread_self(), msg_id);

        struct timespec ts = { .tv_sec  =  DELAY_MS / 1000,
                               .tv_nsec = (DELAY_MS % 1000) * 1000000L };
        nanosleep(&ts, NULL);
    }
    return NULL;
}

/* ------------ управление потоками --------------------------- */
static void spawn(char role)
{
    if (role == 'P' && n_prod < CHILD_MAX)
        pthread_create(&prod[n_prod++], NULL, producer, NULL);
    if (role == 'C' && n_cons < CHILD_MAX)
        pthread_create(&cons[n_cons++], NULL, consumer, NULL);
}

/* ------------ удалить последний поток указанного типа ------------- */
static void cancel_last(char role)
{
    if (role == 'P' && n_prod) { 
        pthread_t tid = prod[n_prod - 1];
        pthread_cancel(tid);
        pthread_join  (tid, NULL);
        --n_prod;
        printf("Производитель %p завершён; осталось производителей: %zu\n",
               (void*)tid, n_prod);
    }

    if (role == 'C' && n_cons) {
        pthread_t tid = cons[n_cons - 1];
        pthread_cancel(tid);
        pthread_join  (tid, NULL);
        --n_cons;
        printf("Потребитель  %p завершён; осталось потребителей:   %zu\n",
               (void*)tid, n_cons);
    }
}

/* ------------ увеличить ёмкость очереди ---------------- */
static void inc_cap(void)
{
    pthread_mutex_lock(&mtx);
    if (queue_capacity() < QUEUE_MAX && queue_inc_cap() == 0) {
        pthread_cond_signal(&cv_free);  /* разблокировать ждущих производителей */
        printf("Ёмкость очереди увеличена до %zu\n", queue_capacity());
    } else {
        fprintf(stderr,
                "Нельзя увеличить: текущая ёмкость %zu (максимум %d)\n",
                queue_capacity(), QUEUE_MAX);
    }
    pthread_mutex_unlock(&mtx);
}

/* ------------ уменьшить ёмкость очереди ---------------- */
static void dec_cap(void)
{
    pthread_mutex_lock(&mtx);
    if (queue_dec_cap() == 0) {
        printf("Ёмкость очереди уменьшена до %zu\n", queue_capacity());
    } else {
        fprintf(stderr,
                "Нельзя уменьшить: нет свободного слота (занято %zu из %zu)\n",
                queue_size(), queue_capacity());
    }
    pthread_mutex_unlock(&mtx);
}

/* ------------ вывести текущее состояние ---------------- */
static void info(void)
{
    printf("Состояние: ёмкость=%zu, занято=%zu, producers=%zu, consumers=%zu\n",
           queue_capacity(), queue_size(), n_prod, n_cons);
}

static void at_exit(void)
{
    while (n_prod) cancel_last('P');
    while (n_cons) cancel_last('C');

    queue_destroy();
    pthread_mutex_destroy(&mtx);
    pthread_cond_destroy (&cv_free);
    pthread_cond_destroy (&cv_used);
}

/* ------------ меню команд ---------------- */
static void menu(void)
{
    puts("Команды:");
    puts("  P – добавить производителя");
    puts("  p – удалить последнего производителя");
    puts("  C – добавить потребителя");
    puts("  c – удалить последнего потребителя");
    puts("  + – увеличить ёмкость очереди");
    puts("  - – уменьшить ёмкость очереди");
    puts("  s – состояние очереди и потоков");
    puts("  q – выход");
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    srand(time(NULL));
    struct sigaction sa = { .sa_handler = sigint_handler };
    sigemptyset(&sa.sa_mask);
    sigaction(SIGINT, &sa, NULL);
    atexit(at_exit);
    queue_init(MSG_CAP0);   /* начальная ёмкость */
    menu();

    int ch;
    while ((ch = getchar()) != 'q' && ch != EOF) {
        switch (ch) {
            case 'P': spawn('P');      break;
            case 'p': cancel_last('P'); break;
            case 'C': spawn('C');      break;
            case 'c': cancel_last('C'); break;
            case '+': inc_cap();       break;
            case '-': dec_cap();       break;
            case 's': info();          break;
            case '\n': break;          /* игнорируем ENTER */
            default:
                puts("Неизвестная команда, 'q' – выход.");
        }
    }
    return 0;
}
